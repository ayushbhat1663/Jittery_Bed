gdjs.GameSceneCode = {};
gdjs.GameSceneCode.localVariables = [];
gdjs.GameSceneCode.GDBlockObjects4_1final = [];

gdjs.GameSceneCode.GDEnemyObjects4_1final = [];

gdjs.GameSceneCode.forEachIndex3 = 0;

gdjs.GameSceneCode.forEachObjects3 = [];

gdjs.GameSceneCode.forEachTemporary3 = null;

gdjs.GameSceneCode.forEachTotalCount3 = 0;

gdjs.GameSceneCode.GDPlayerObjects1= [];
gdjs.GameSceneCode.GDPlayerObjects2= [];
gdjs.GameSceneCode.GDPlayerObjects3= [];
gdjs.GameSceneCode.GDPlayerObjects4= [];
gdjs.GameSceneCode.GDPlayerObjects5= [];
gdjs.GameSceneCode.GDPlayerObjects6= [];
gdjs.GameSceneCode.GDAimObjects1= [];
gdjs.GameSceneCode.GDAimObjects2= [];
gdjs.GameSceneCode.GDAimObjects3= [];
gdjs.GameSceneCode.GDAimObjects4= [];
gdjs.GameSceneCode.GDAimObjects5= [];
gdjs.GameSceneCode.GDAimObjects6= [];
gdjs.GameSceneCode.GDCursorObjects1= [];
gdjs.GameSceneCode.GDCursorObjects2= [];
gdjs.GameSceneCode.GDCursorObjects3= [];
gdjs.GameSceneCode.GDCursorObjects4= [];
gdjs.GameSceneCode.GDCursorObjects5= [];
gdjs.GameSceneCode.GDCursorObjects6= [];
gdjs.GameSceneCode.GDGunObjects1= [];
gdjs.GameSceneCode.GDGunObjects2= [];
gdjs.GameSceneCode.GDGunObjects3= [];
gdjs.GameSceneCode.GDGunObjects4= [];
gdjs.GameSceneCode.GDGunObjects5= [];
gdjs.GameSceneCode.GDGunObjects6= [];
gdjs.GameSceneCode.GDBulletObjects1= [];
gdjs.GameSceneCode.GDBulletObjects2= [];
gdjs.GameSceneCode.GDBulletObjects3= [];
gdjs.GameSceneCode.GDBulletObjects4= [];
gdjs.GameSceneCode.GDBulletObjects5= [];
gdjs.GameSceneCode.GDBulletObjects6= [];
gdjs.GameSceneCode.GDEnemyObjects1= [];
gdjs.GameSceneCode.GDEnemyObjects2= [];
gdjs.GameSceneCode.GDEnemyObjects3= [];
gdjs.GameSceneCode.GDEnemyObjects4= [];
gdjs.GameSceneCode.GDEnemyObjects5= [];
gdjs.GameSceneCode.GDEnemyObjects6= [];
gdjs.GameSceneCode.GDCollectableObjects1= [];
gdjs.GameSceneCode.GDCollectableObjects2= [];
gdjs.GameSceneCode.GDCollectableObjects3= [];
gdjs.GameSceneCode.GDCollectableObjects4= [];
gdjs.GameSceneCode.GDCollectableObjects5= [];
gdjs.GameSceneCode.GDCollectableObjects6= [];
gdjs.GameSceneCode.GDBlockObjects1= [];
gdjs.GameSceneCode.GDBlockObjects2= [];
gdjs.GameSceneCode.GDBlockObjects3= [];
gdjs.GameSceneCode.GDBlockObjects4= [];
gdjs.GameSceneCode.GDBlockObjects5= [];
gdjs.GameSceneCode.GDBlockObjects6= [];
gdjs.GameSceneCode.GDGrassObjects1= [];
gdjs.GameSceneCode.GDGrassObjects2= [];
gdjs.GameSceneCode.GDGrassObjects3= [];
gdjs.GameSceneCode.GDGrassObjects4= [];
gdjs.GameSceneCode.GDGrassObjects5= [];
gdjs.GameSceneCode.GDGrassObjects6= [];
gdjs.GameSceneCode.GDTreeObjects1= [];
gdjs.GameSceneCode.GDTreeObjects2= [];
gdjs.GameSceneCode.GDTreeObjects3= [];
gdjs.GameSceneCode.GDTreeObjects4= [];
gdjs.GameSceneCode.GDTreeObjects5= [];
gdjs.GameSceneCode.GDTreeObjects6= [];
gdjs.GameSceneCode.GDBulletEffectObjects1= [];
gdjs.GameSceneCode.GDBulletEffectObjects2= [];
gdjs.GameSceneCode.GDBulletEffectObjects3= [];
gdjs.GameSceneCode.GDBulletEffectObjects4= [];
gdjs.GameSceneCode.GDBulletEffectObjects5= [];
gdjs.GameSceneCode.GDBulletEffectObjects6= [];
gdjs.GameSceneCode.GDEnemyBloodObjects1= [];
gdjs.GameSceneCode.GDEnemyBloodObjects2= [];
gdjs.GameSceneCode.GDEnemyBloodObjects3= [];
gdjs.GameSceneCode.GDEnemyBloodObjects4= [];
gdjs.GameSceneCode.GDEnemyBloodObjects5= [];
gdjs.GameSceneCode.GDEnemyBloodObjects6= [];
gdjs.GameSceneCode.GDHudTextHpObjects1= [];
gdjs.GameSceneCode.GDHudTextHpObjects2= [];
gdjs.GameSceneCode.GDHudTextHpObjects3= [];
gdjs.GameSceneCode.GDHudTextHpObjects4= [];
gdjs.GameSceneCode.GDHudTextHpObjects5= [];
gdjs.GameSceneCode.GDHudTextHpObjects6= [];
gdjs.GameSceneCode.GDHudTextCoinsObjects1= [];
gdjs.GameSceneCode.GDHudTextCoinsObjects2= [];
gdjs.GameSceneCode.GDHudTextCoinsObjects3= [];
gdjs.GameSceneCode.GDHudTextCoinsObjects4= [];
gdjs.GameSceneCode.GDHudTextCoinsObjects5= [];
gdjs.GameSceneCode.GDHudTextCoinsObjects6= [];
gdjs.GameSceneCode.GDHudTextKillsObjects1= [];
gdjs.GameSceneCode.GDHudTextKillsObjects2= [];
gdjs.GameSceneCode.GDHudTextKillsObjects3= [];
gdjs.GameSceneCode.GDHudTextKillsObjects4= [];
gdjs.GameSceneCode.GDHudTextKillsObjects5= [];
gdjs.GameSceneCode.GDHudTextKillsObjects6= [];
gdjs.GameSceneCode.GDHomeButtonObjects1= [];
gdjs.GameSceneCode.GDHomeButtonObjects2= [];
gdjs.GameSceneCode.GDHomeButtonObjects3= [];
gdjs.GameSceneCode.GDHomeButtonObjects4= [];
gdjs.GameSceneCode.GDHomeButtonObjects5= [];
gdjs.GameSceneCode.GDHomeButtonObjects6= [];
gdjs.GameSceneCode.GDRestartButtonObjects1= [];
gdjs.GameSceneCode.GDRestartButtonObjects2= [];
gdjs.GameSceneCode.GDRestartButtonObjects3= [];
gdjs.GameSceneCode.GDRestartButtonObjects4= [];
gdjs.GameSceneCode.GDRestartButtonObjects5= [];
gdjs.GameSceneCode.GDRestartButtonObjects6= [];
gdjs.GameSceneCode.GDHudObjects1= [];
gdjs.GameSceneCode.GDHudObjects2= [];
gdjs.GameSceneCode.GDHudObjects3= [];
gdjs.GameSceneCode.GDHudObjects4= [];
gdjs.GameSceneCode.GDHudObjects5= [];
gdjs.GameSceneCode.GDHudObjects6= [];


gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHudTextKillsObjects3Objects = Hashtable.newFrom({"HudTextKills": gdjs.GameSceneCode.GDHudTextKillsObjects3});
gdjs.GameSceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.GameSceneCode.GDHudTextKillsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHudTextKillsObjects3Objects, 500, 10, "Hud");
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setWrappingWidth(1500);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setGradient("LINEAR_VERTICAL", "255;251;198", "235;226;120", "168;158;39", "116;108;23");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setOutline("0;0;0", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects3[i].setPosition(500,10);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHudTextCoinsObjects3Objects = Hashtable.newFrom({"HudTextCoins": gdjs.GameSceneCode.GDHudTextCoinsObjects3});
gdjs.GameSceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.GameSceneCode.GDHudTextCoinsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHudTextCoinsObjects3Objects, 184, 10, "Hud");
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setWrappingWidth(1500);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setGradient("LINEAR_VERTICAL", "255;251;198", "235;226;120", "168;158;39", "116;108;23");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setOutline("0;0;0", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects3[i].setPosition(184,10);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHudTextHpObjects2Objects = Hashtable.newFrom({"HudTextHp": gdjs.GameSceneCode.GDHudTextHpObjects2});
gdjs.GameSceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.GameSceneCode.GDHudTextHpObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHudTextHpObjects2Objects, 28, 10, "Hud");
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setGradient("LINEAR_VERTICAL", "220;255;181", "162;228;89", "134;214;42", "77;129;14");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setOutline("0;0;0", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setWrappingWidth(1000);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setPosition(28,10);
}
}}

}


};gdjs.GameSceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList0(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList1(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList2(runtimeScene);
}


};gdjs.GameSceneCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HudTextCoins"), gdjs.GameSceneCode.GDHudTextCoinsObjects2);
gdjs.copyArray(runtimeScene.getObjects("HudTextHp"), gdjs.GameSceneCode.GDHudTextHpObjects2);
gdjs.copyArray(runtimeScene.getObjects("HudTextKills"), gdjs.GameSceneCode.GDHudTextKillsObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextKillsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextKillsObjects2[i].setString("Total Kills: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextHpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextHpObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)) + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHudTextCoinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHudTextCoinsObjects2[i].setString("Coins:" + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.GameSceneCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins"));
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "coins", 0);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "coins", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}}

}


};gdjs.GameSceneCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("PlayerHp")) <= 0;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("PlayerHp").setNumber(100);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "player_hp", 100);
}}

}


};gdjs.GameSceneCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "player_hp"));
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "player_hp", 100);
}{runtimeScene.getScene().getVariables().get("PlayerHp").setNumber(100);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "player_hp");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "player_hp", runtimeScene, runtimeScene.getScene().getVariables().get("PlayerHp"));
}
{ //Subevents
gdjs.GameSceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "player_max_hp"));
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "player_max_hp", 100);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(100);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "player_max_hp");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "player_max_hp", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(2));
}}

}


};gdjs.GameSceneCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "total_kills"));
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "total_kills", 0);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "total_kills");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "total_kills", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3));
}}

}


};gdjs.GameSceneCode.eventsList11 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList6(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList8(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList9(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList10(runtimeScene);
}


};gdjs.GameSceneCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GameSceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects2});
gdjs.GameSceneCode.eventsList13 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList14 = function(runtimeScene) {

{


const repeatCount2 = 5;
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.GameSceneCode.GDEnemyObjects2.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects2Objects, gdjs.randomInRange(48, 568), gdjs.randomInRange(48, 280), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects2[i].setVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(0), false);
}
}}
}

}


};gdjs.GameSceneCode.eventsList15 = function(runtimeScene) {

{



}


{



}


{


gdjs.GameSceneCode.eventsList12(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList14(runtimeScene);
}


};gdjs.GameSceneCode.eventsList16 = function(runtimeScene) {

{



}


{



}


{


gdjs.GameSceneCode.eventsList4(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList5(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Aim"), gdjs.GameSceneCode.GDAimObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn");
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(100);
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.GameSceneCode.GDAimObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDAimObjects1[i].hide();
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects2);

{gdjs.evtTools.camera.centerCameraWithinLimits(runtimeScene, (gdjs.GameSceneCode.GDPlayerObjects2.length !== 0 ? gdjs.GameSceneCode.GDPlayerObjects2[0] : null), 0, 0, 640, 360, true, "", 0);
}}

}


};gdjs.GameSceneCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameSceneCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameSceneCode.GDGunObjects2);
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects2[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGunObjects2[i].setPosition((( gdjs.GameSceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjects2[0].getPointX("")),(( gdjs.GameSceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjects2[0].getPointY("")));
}
}}

}


};gdjs.GameSceneCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].getBehavior("TopDownMovement").simulateRightKey();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].addForce(1, (gdjs.GameSceneCode.GDPlayerObjects4[i].getAverageForce().getY()), 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].addForce(-(1), (gdjs.GameSceneCode.GDPlayerObjects4[i].getAverageForce().getY()), 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].getBehavior("TopDownMovement").simulateUpKey();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].addForce((gdjs.GameSceneCode.GDPlayerObjects4[i].getAverageForce().getX()), 1, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").simulateDownKey();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects3[i].addForce((gdjs.GameSceneCode.GDPlayerObjects3[i].getAverageForce().getX()), -(1), 0);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.GameSceneCode.GDPlayerObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDCollectableObjects4Objects = Hashtable.newFrom({"Collectable": gdjs.GameSceneCode.GDCollectableObjects4});
gdjs.GameSceneCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDCollectableObjects4, gdjs.GameSceneCode.GDCollectableObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDCollectableObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDCollectableObjects5[i].isCurrentAnimationName("potion") ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDCollectableObjects5[k] = gdjs.GameSceneCode.GDCollectableObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDCollectableObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2));
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(100);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets/sounds/collectable.wav", 22, false, 100, 1);
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDCollectableObjects4, gdjs.GameSceneCode.GDCollectableObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDCollectableObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDCollectableObjects5[i].isCurrentAnimationName("coin") ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDCollectableObjects5[k] = gdjs.GameSceneCode.GDCollectableObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDCollectableObjects5.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "coins", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\coin_drop.wav", 22, false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameSceneCode.GDCollectableObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDCollectableObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCollectableObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Collectable"), gdjs.GameSceneCode.GDCollectableObjects4);
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDCollectableObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12240700);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(100);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.GameSceneCode.GDPlayerObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects3Objects = Hashtable.newFrom({"Block": gdjs.GameSceneCode.GDBlockObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects3Objects = Hashtable.newFrom({"Block": gdjs.GameSceneCode.GDBlockObjects3});
gdjs.GameSceneCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.GameSceneCode.GDBlockObjects3);
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects3Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBlockObjects3 */
/* Reuse gdjs.GameSceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects3[i].separateFromObjectsList(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects3Objects, false);
}
}}

}


};gdjs.GameSceneCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjects4[i].hasNoForces() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjects4[k] = gdjs.GameSceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].setAnimationName("idle");
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjects3[k] = gdjs.GameSceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects3[i].setAnimationName("run");
}
}}

}


};gdjs.GameSceneCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameSceneCode.GDGunObjects4);
{for(var i = 0, len = gdjs.GameSceneCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGunObjects4[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjects4[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjects4[k] = gdjs.GameSceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameSceneCode.GDGunObjects4);
/* Reuse gdjs.GameSceneCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGunObjects4[i].flipX(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGunObjects4[i].flipY(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].flipX(false);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjects3[i].getX() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjects3[k] = gdjs.GameSceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameSceneCode.GDGunObjects3);
/* Reuse gdjs.GameSceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGunObjects3[i].flipX(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGunObjects3[i].flipY(true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects3[i].flipX(true);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.GameSceneCode.GDBulletObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects3Objects = Hashtable.newFrom({"Block": gdjs.GameSceneCode.GDBlockObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletEffectObjects3Objects = Hashtable.newFrom({"BulletEffect": gdjs.GameSceneCode.GDBulletEffectObjects3});
gdjs.GameSceneCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.GameSceneCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameSceneCode.GDBulletObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletObjects3Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBulletObjects3 */
gdjs.GameSceneCode.GDBulletEffectObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletEffectObjects3Objects, (( gdjs.GameSceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDBulletObjects3[0].getPointX("")), (( gdjs.GameSceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) <= 0;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true);
}}

}


};gdjs.GameSceneCode.eventsList27 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList19(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList21(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList22(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList23(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList24(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList25(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList26(runtimeScene);
}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.GameSceneCode.GDBulletObjects2});
gdjs.GameSceneCode.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12252868);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDAimObjects1, gdjs.GameSceneCode.GDAimObjects2);

gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameSceneCode.GDGunObjects2);
gdjs.GameSceneCode.GDBulletObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletObjects2Objects, (( gdjs.GameSceneCode.GDGunObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDGunObjects2[0].getPointX("bullet_right")), (( gdjs.GameSceneCode.GDGunObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDGunObjects2[0].getPointY("bullet_right")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBulletObjects2[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBulletObjects2[i].setAngle((( gdjs.GameSceneCode.GDAimObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDAimObjects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBulletObjects2[i].addPolarForce((( gdjs.GameSceneCode.GDAimObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDAimObjects2[0].getAngle()), 200, 1);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\player_bullet.wav", 22, false, 10, 1);
}{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 2, 2, "", 0, 0.25, 1, 1, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects5Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects5});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects5Objects = Hashtable.newFrom({"Block": gdjs.GameSceneCode.GDBlockObjects5});
gdjs.GameSceneCode.eventsList29 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);

gdjs.GameSceneCode.GDBlockObjects4.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDEnemyObjects4[i].getVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects4[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects4[k] = gdjs.GameSceneCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.GameSceneCode.GDBlockObjects4_1final.length = 0;
gdjs.GameSceneCode.GDEnemyObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.GameSceneCode.GDBlockObjects5);
gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects4, gdjs.GameSceneCode.GDEnemyObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects5Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameSceneCode.GDBlockObjects5.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDBlockObjects4_1final.indexOf(gdjs.GameSceneCode.GDBlockObjects5[j]) === -1 )
            gdjs.GameSceneCode.GDBlockObjects4_1final.push(gdjs.GameSceneCode.GDBlockObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.GameSceneCode.GDEnemyObjects5.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDEnemyObjects4_1final.indexOf(gdjs.GameSceneCode.GDEnemyObjects5[j]) === -1 )
            gdjs.GameSceneCode.GDEnemyObjects4_1final.push(gdjs.GameSceneCode.GDEnemyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDBlockObjects4_1final, gdjs.GameSceneCode.GDBlockObjects4);
gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects4_1final, gdjs.GameSceneCode.GDEnemyObjects4);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.eventsList30 = function(runtimeScene) {

{


const repeatCount3 = 5;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects2, gdjs.GameSceneCode.GDEnemyObjects3);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects3Objects, gdjs.randomInRange(48, 568), gdjs.randomInRange(48, 280), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects3[i].setVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(0), false);
}
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList29(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameSceneCode.GDEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects2Objects) < 3);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList32 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "Spawn");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn");
}
{ //Subevents
gdjs.GameSceneCode.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects4Objects = Hashtable.newFrom({"Block": gdjs.GameSceneCode.GDBlockObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects4Objects = Hashtable.newFrom({"Block": gdjs.GameSceneCode.GDBlockObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.GameSceneCode.GDPlayerObjects4});
gdjs.GameSceneCode.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects4, gdjs.GameSceneCode.GDEnemyObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDEnemyObjects5[i].hasNoForces() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects5[k] = gdjs.GameSceneCode.GDEnemyObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects5[i].setAnimationName("idle");
}
}}

}


{

/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects4.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDEnemyObjects4[i].hasNoForces()) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects4[k] = gdjs.GameSceneCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].setAnimationName("run");
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects4});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.GameSceneCode.GDPlayerObjects4});
gdjs.GameSceneCode.eventsList34 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12266628);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameSceneCode.GDGunObjects4);
/* Reuse gdjs.GameSceneCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjects4[i].getBehavior("Flash").Flash(2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGunObjects4[i].getBehavior("Flash").Flash(2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).sub(20);
}}

}


};gdjs.GameSceneCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDEnemyObjects5[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects5[k] = gdjs.GameSceneCode.GDEnemyObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDEnemyObjects5[i].isCurrentAnimationName("attack") ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects5[k] = gdjs.GameSceneCode.GDEnemyObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects5[i].setVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects5[i].getVariables().getFromIndex(0), false);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDEnemyObjects4[i].timerElapsedTime("attack", 0.8) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects4[k] = gdjs.GameSceneCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].removeTimer("attack");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].setVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects4[i].getVariables().getFromIndex(0), false);
}
}}

}


};gdjs.GameSceneCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjects4[i].getX() < (( gdjs.GameSceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects4[0].getPointX("")) - ((( gdjs.GameSceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects4[0].getWidth()) / 2) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjects4[k] = gdjs.GameSceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].flipX(false);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjects4[i].getX() > (( gdjs.GameSceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects4[0].getPointX("")) + ((( gdjs.GameSceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects4[0].getWidth()) / 2) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjects4[k] = gdjs.GameSceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.GameSceneCode.GDBlockObjects4);
gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBlockObjects4 */
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].separateFromObjectsList(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBlockObjects4Objects, true);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].separateFromObjectsList(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects, true);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects4Objects, 150, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
/* Reuse gdjs.GameSceneCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].addForceTowardObject((gdjs.GameSceneCode.GDPlayerObjects4.length !== 0 ? gdjs.GameSceneCode.GDPlayerObjects4[0] : null), 30, 0);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDEnemyObjects4[i].getVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects4[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects4[k] = gdjs.GameSceneCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList33(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDEnemyObjects3, gdjs.GameSceneCode.GDEnemyObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjects1, gdjs.GameSceneCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDPlayerObjects4[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjects4[k] = gdjs.GameSceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDEnemyObjects4[i].getVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects4[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDEnemyObjects4[k] = gdjs.GameSceneCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDEnemyObjects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDEnemyObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].setVariableBoolean(gdjs.GameSceneCode.GDEnemyObjects4[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].setAnimationName("attack");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects4[i].resetTimer("attack");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList34(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.eventsList35(runtimeScene);
}


};gdjs.GameSceneCode.eventsList37 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameSceneCode.GDEnemyObjects2);

for (gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDEnemyObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDEnemyObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDEnemyObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDEnemyObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList36(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.GameSceneCode.GDEnemyObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.GameSceneCode.GDBulletObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyBloodObjects1Objects = Hashtable.newFrom({"EnemyBlood": gdjs.GameSceneCode.GDEnemyBloodObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletEffectObjects1Objects = Hashtable.newFrom({"BulletEffect": gdjs.GameSceneCode.GDBulletEffectObjects1});
gdjs.GameSceneCode.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameSceneCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameSceneCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyObjects1Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBulletObjects1 */
/* Reuse gdjs.GameSceneCode.GDEnemyObjects1 */
gdjs.GameSceneCode.GDBulletEffectObjects1.length = 0;

gdjs.GameSceneCode.GDEnemyBloodObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDEnemyBloodObjects1Objects, (( gdjs.GameSceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.GameSceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects1[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBulletEffectObjects1Objects, (( gdjs.GameSceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.GameSceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDEnemyObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets/sounds/crashbones.wav", 23, false, 60, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "total_kills", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}}

}


};gdjs.GameSceneCode.eventsList39 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList32(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList37(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList38(runtimeScene);
}


};gdjs.GameSceneCode.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12232164);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameSceneCode.GDCursorObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects2[i].setAnimationName("obj_cursor");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects2[i].setLayer("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects2[i].setZOrder(1000);
}
}}

}


{


gdjs.GameSceneCode.eventsList17(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList18(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList27(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList28(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList39(runtimeScene);
}


};gdjs.GameSceneCode.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Aim"), gdjs.GameSceneCode.GDAimObjects1);
gdjs.copyArray(runtimeScene.getObjects("HomeButton"), gdjs.GameSceneCode.GDHomeButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameSceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartButton"), gdjs.GameSceneCode.GDRestartButtonObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDAimObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDAimObjects1[i].setPosition((( gdjs.GameSceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjects1[0].getPointX("")),(( gdjs.GameSceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDAimObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDAimObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDRestartButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHomeButtonObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHomeButtonObjects1[i].hide();
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHomeButtonObjects2Objects = Hashtable.newFrom({"HomeButton": gdjs.GameSceneCode.GDHomeButtonObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDRestartButtonObjects1Objects = Hashtable.newFrom({"RestartButton": gdjs.GameSceneCode.GDRestartButtonObjects1});
gdjs.GameSceneCode.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDHomeButtonObjects1, gdjs.GameSceneCode.GDHomeButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHomeButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDHomeButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDHomeButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDHomeButtonObjects2[k] = gdjs.GameSceneCode.GDHomeButtonObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDHomeButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12274324);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainScene", true);
}}

}


{

/* Reuse gdjs.GameSceneCode.GDRestartButtonObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDRestartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDRestartButtonObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDRestartButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDRestartButtonObjects1[k] = gdjs.GameSceneCode.GDRestartButtonObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDRestartButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12275740);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Hud");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Gameover");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameScene", true);
}}

}


};gdjs.GameSceneCode.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameSceneCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("HomeButton"), gdjs.GameSceneCode.GDHomeButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartButton"), gdjs.GameSceneCode.GDRestartButtonObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects1[i].setAnimationName("obj_cursor_2");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects1[i].setLayer("Hud");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects1[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDHomeButtonObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDHomeButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDRestartButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCursorObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "Hud", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "Hud", 0));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList42(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList44 = function(runtimeScene) {

{



}


{



}


{



}


{


gdjs.GameSceneCode.eventsList16(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList41(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList43(runtimeScene);
}


};

gdjs.GameSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameSceneCode.GDPlayerObjects1.length = 0;
gdjs.GameSceneCode.GDPlayerObjects2.length = 0;
gdjs.GameSceneCode.GDPlayerObjects3.length = 0;
gdjs.GameSceneCode.GDPlayerObjects4.length = 0;
gdjs.GameSceneCode.GDPlayerObjects5.length = 0;
gdjs.GameSceneCode.GDPlayerObjects6.length = 0;
gdjs.GameSceneCode.GDAimObjects1.length = 0;
gdjs.GameSceneCode.GDAimObjects2.length = 0;
gdjs.GameSceneCode.GDAimObjects3.length = 0;
gdjs.GameSceneCode.GDAimObjects4.length = 0;
gdjs.GameSceneCode.GDAimObjects5.length = 0;
gdjs.GameSceneCode.GDAimObjects6.length = 0;
gdjs.GameSceneCode.GDCursorObjects1.length = 0;
gdjs.GameSceneCode.GDCursorObjects2.length = 0;
gdjs.GameSceneCode.GDCursorObjects3.length = 0;
gdjs.GameSceneCode.GDCursorObjects4.length = 0;
gdjs.GameSceneCode.GDCursorObjects5.length = 0;
gdjs.GameSceneCode.GDCursorObjects6.length = 0;
gdjs.GameSceneCode.GDGunObjects1.length = 0;
gdjs.GameSceneCode.GDGunObjects2.length = 0;
gdjs.GameSceneCode.GDGunObjects3.length = 0;
gdjs.GameSceneCode.GDGunObjects4.length = 0;
gdjs.GameSceneCode.GDGunObjects5.length = 0;
gdjs.GameSceneCode.GDGunObjects6.length = 0;
gdjs.GameSceneCode.GDBulletObjects1.length = 0;
gdjs.GameSceneCode.GDBulletObjects2.length = 0;
gdjs.GameSceneCode.GDBulletObjects3.length = 0;
gdjs.GameSceneCode.GDBulletObjects4.length = 0;
gdjs.GameSceneCode.GDBulletObjects5.length = 0;
gdjs.GameSceneCode.GDBulletObjects6.length = 0;
gdjs.GameSceneCode.GDEnemyObjects1.length = 0;
gdjs.GameSceneCode.GDEnemyObjects2.length = 0;
gdjs.GameSceneCode.GDEnemyObjects3.length = 0;
gdjs.GameSceneCode.GDEnemyObjects4.length = 0;
gdjs.GameSceneCode.GDEnemyObjects5.length = 0;
gdjs.GameSceneCode.GDEnemyObjects6.length = 0;
gdjs.GameSceneCode.GDCollectableObjects1.length = 0;
gdjs.GameSceneCode.GDCollectableObjects2.length = 0;
gdjs.GameSceneCode.GDCollectableObjects3.length = 0;
gdjs.GameSceneCode.GDCollectableObjects4.length = 0;
gdjs.GameSceneCode.GDCollectableObjects5.length = 0;
gdjs.GameSceneCode.GDCollectableObjects6.length = 0;
gdjs.GameSceneCode.GDBlockObjects1.length = 0;
gdjs.GameSceneCode.GDBlockObjects2.length = 0;
gdjs.GameSceneCode.GDBlockObjects3.length = 0;
gdjs.GameSceneCode.GDBlockObjects4.length = 0;
gdjs.GameSceneCode.GDBlockObjects5.length = 0;
gdjs.GameSceneCode.GDBlockObjects6.length = 0;
gdjs.GameSceneCode.GDGrassObjects1.length = 0;
gdjs.GameSceneCode.GDGrassObjects2.length = 0;
gdjs.GameSceneCode.GDGrassObjects3.length = 0;
gdjs.GameSceneCode.GDGrassObjects4.length = 0;
gdjs.GameSceneCode.GDGrassObjects5.length = 0;
gdjs.GameSceneCode.GDGrassObjects6.length = 0;
gdjs.GameSceneCode.GDTreeObjects1.length = 0;
gdjs.GameSceneCode.GDTreeObjects2.length = 0;
gdjs.GameSceneCode.GDTreeObjects3.length = 0;
gdjs.GameSceneCode.GDTreeObjects4.length = 0;
gdjs.GameSceneCode.GDTreeObjects5.length = 0;
gdjs.GameSceneCode.GDTreeObjects6.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects1.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects2.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects3.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects4.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects5.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects6.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects1.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects2.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects3.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects4.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects5.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects6.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects1.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects2.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects3.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects4.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects5.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects6.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects1.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects2.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects3.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects4.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects5.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects6.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects1.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects2.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects3.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects4.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects5.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects6.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects1.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects2.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects3.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects4.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects5.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects6.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects1.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects2.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects3.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects4.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects5.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects6.length = 0;
gdjs.GameSceneCode.GDHudObjects1.length = 0;
gdjs.GameSceneCode.GDHudObjects2.length = 0;
gdjs.GameSceneCode.GDHudObjects3.length = 0;
gdjs.GameSceneCode.GDHudObjects4.length = 0;
gdjs.GameSceneCode.GDHudObjects5.length = 0;
gdjs.GameSceneCode.GDHudObjects6.length = 0;

gdjs.GameSceneCode.eventsList44(runtimeScene);
gdjs.GameSceneCode.GDPlayerObjects1.length = 0;
gdjs.GameSceneCode.GDPlayerObjects2.length = 0;
gdjs.GameSceneCode.GDPlayerObjects3.length = 0;
gdjs.GameSceneCode.GDPlayerObjects4.length = 0;
gdjs.GameSceneCode.GDPlayerObjects5.length = 0;
gdjs.GameSceneCode.GDPlayerObjects6.length = 0;
gdjs.GameSceneCode.GDAimObjects1.length = 0;
gdjs.GameSceneCode.GDAimObjects2.length = 0;
gdjs.GameSceneCode.GDAimObjects3.length = 0;
gdjs.GameSceneCode.GDAimObjects4.length = 0;
gdjs.GameSceneCode.GDAimObjects5.length = 0;
gdjs.GameSceneCode.GDAimObjects6.length = 0;
gdjs.GameSceneCode.GDCursorObjects1.length = 0;
gdjs.GameSceneCode.GDCursorObjects2.length = 0;
gdjs.GameSceneCode.GDCursorObjects3.length = 0;
gdjs.GameSceneCode.GDCursorObjects4.length = 0;
gdjs.GameSceneCode.GDCursorObjects5.length = 0;
gdjs.GameSceneCode.GDCursorObjects6.length = 0;
gdjs.GameSceneCode.GDGunObjects1.length = 0;
gdjs.GameSceneCode.GDGunObjects2.length = 0;
gdjs.GameSceneCode.GDGunObjects3.length = 0;
gdjs.GameSceneCode.GDGunObjects4.length = 0;
gdjs.GameSceneCode.GDGunObjects5.length = 0;
gdjs.GameSceneCode.GDGunObjects6.length = 0;
gdjs.GameSceneCode.GDBulletObjects1.length = 0;
gdjs.GameSceneCode.GDBulletObjects2.length = 0;
gdjs.GameSceneCode.GDBulletObjects3.length = 0;
gdjs.GameSceneCode.GDBulletObjects4.length = 0;
gdjs.GameSceneCode.GDBulletObjects5.length = 0;
gdjs.GameSceneCode.GDBulletObjects6.length = 0;
gdjs.GameSceneCode.GDEnemyObjects1.length = 0;
gdjs.GameSceneCode.GDEnemyObjects2.length = 0;
gdjs.GameSceneCode.GDEnemyObjects3.length = 0;
gdjs.GameSceneCode.GDEnemyObjects4.length = 0;
gdjs.GameSceneCode.GDEnemyObjects5.length = 0;
gdjs.GameSceneCode.GDEnemyObjects6.length = 0;
gdjs.GameSceneCode.GDCollectableObjects1.length = 0;
gdjs.GameSceneCode.GDCollectableObjects2.length = 0;
gdjs.GameSceneCode.GDCollectableObjects3.length = 0;
gdjs.GameSceneCode.GDCollectableObjects4.length = 0;
gdjs.GameSceneCode.GDCollectableObjects5.length = 0;
gdjs.GameSceneCode.GDCollectableObjects6.length = 0;
gdjs.GameSceneCode.GDBlockObjects1.length = 0;
gdjs.GameSceneCode.GDBlockObjects2.length = 0;
gdjs.GameSceneCode.GDBlockObjects3.length = 0;
gdjs.GameSceneCode.GDBlockObjects4.length = 0;
gdjs.GameSceneCode.GDBlockObjects5.length = 0;
gdjs.GameSceneCode.GDBlockObjects6.length = 0;
gdjs.GameSceneCode.GDGrassObjects1.length = 0;
gdjs.GameSceneCode.GDGrassObjects2.length = 0;
gdjs.GameSceneCode.GDGrassObjects3.length = 0;
gdjs.GameSceneCode.GDGrassObjects4.length = 0;
gdjs.GameSceneCode.GDGrassObjects5.length = 0;
gdjs.GameSceneCode.GDGrassObjects6.length = 0;
gdjs.GameSceneCode.GDTreeObjects1.length = 0;
gdjs.GameSceneCode.GDTreeObjects2.length = 0;
gdjs.GameSceneCode.GDTreeObjects3.length = 0;
gdjs.GameSceneCode.GDTreeObjects4.length = 0;
gdjs.GameSceneCode.GDTreeObjects5.length = 0;
gdjs.GameSceneCode.GDTreeObjects6.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects1.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects2.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects3.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects4.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects5.length = 0;
gdjs.GameSceneCode.GDBulletEffectObjects6.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects1.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects2.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects3.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects4.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects5.length = 0;
gdjs.GameSceneCode.GDEnemyBloodObjects6.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects1.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects2.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects3.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects4.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects5.length = 0;
gdjs.GameSceneCode.GDHudTextHpObjects6.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects1.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects2.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects3.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects4.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects5.length = 0;
gdjs.GameSceneCode.GDHudTextCoinsObjects6.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects1.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects2.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects3.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects4.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects5.length = 0;
gdjs.GameSceneCode.GDHudTextKillsObjects6.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects1.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects2.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects3.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects4.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects5.length = 0;
gdjs.GameSceneCode.GDHomeButtonObjects6.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects1.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects2.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects3.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects4.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects5.length = 0;
gdjs.GameSceneCode.GDRestartButtonObjects6.length = 0;
gdjs.GameSceneCode.GDHudObjects1.length = 0;
gdjs.GameSceneCode.GDHudObjects2.length = 0;
gdjs.GameSceneCode.GDHudObjects3.length = 0;
gdjs.GameSceneCode.GDHudObjects4.length = 0;
gdjs.GameSceneCode.GDHudObjects5.length = 0;
gdjs.GameSceneCode.GDHudObjects6.length = 0;


return;

}

gdjs['GameSceneCode'] = gdjs.GameSceneCode;
